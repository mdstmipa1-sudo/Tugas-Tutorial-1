"use strict";

/* =====================================================
   SITTA - script.js
   Satu file dipakai semua halaman. Halaman dikenali dari
   atribut <body data-halaman="...">.
   ===================================================== */

const KUNCI_SESI = "sitta_pengguna_aktif";
const KUNCI_DAFTAR = "sitta_pengguna_tambahan";
const TAHAP_KIRIM = ["Diproses", "Dikirim", "Dalam Perjalanan", "Diterima"];
const BATAS_STOK_MENIPIS = 200;

// data.js menyimpan dataTracking sebagai objek berkunci nomor DO.
// Diubah ke array agar mudah di-loop. Nomor DO diambil dari KUNCI objek,
// bukan properti nomorDO, karena pada data contoh keduanya bisa berbeda.
function indeksStatus(status) {
  const i = TAHAP_KIRIM.findIndex((t) => t.toLowerCase() === String(status).toLowerCase());
  return i === -1 ? 0 : i;
}
const daftarTracking = Object.entries(dataTracking).map(([nomor, d]) => ({
  ...d, nomorDO: nomor, statusIdx: indeksStatus(d.status)
}));

// Kolom "paket" berisi kode lokasi bahan ajar; cari nama barangnya
function namaPaket(kode) {
  const barang = dataBahanAjar.find((b) => b.kodeLokasi === kode);
  return barang ? barang.namaBarang + " (" + kode + ")" : kode;
}

/* ---------- Util umum ---------- */

// Membuat elemen dengan kelas dan teks (memakai textContent, aman dari injeksi HTML)
function buat(tag, kelas, teks) {
  const el = document.createElement(tag);
  if (kelas) el.className = kelas;
  if (teks !== undefined) el.textContent = teks;
  return el;
}

const tanggalPanjang = (iso) =>
  new Date(iso + "T00:00:00").toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
const emailValid = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

// Menampilkan / menghapus pesan galat di bawah input (id span: "galat-" + id input)
function setGalat(idInput, pesan) {
  const input = document.getElementById(idInput);
  const span = document.getElementById("galat-" + idInput);
  if (span) span.textContent = pesan || "";
  if (input) {
    input.classList.toggle("tidak-valid", Boolean(pesan));
    input.setAttribute("aria-invalid", pesan ? "true" : "false");
  }
}

/* ---------- Sesi & pengguna ---------- */

function semuaPengguna() {
  let tambahan = [];
  try { tambahan = JSON.parse(localStorage.getItem(KUNCI_DAFTAR)) || []; } catch (e) { /* abaikan */ }
  return dataPengguna.concat(tambahan);
}

function penggunaAktif() {
  try { return JSON.parse(sessionStorage.getItem(KUNCI_SESI)); } catch (e) { return null; }
}

/* ---------- Dialog: alert kustom & modal ---------- */

function tampilAlert(judul, pesan, tipe) {
  let dlg = document.getElementById("dialog-alert");
  if (!dlg) {
    dlg = buat("dialog", "modal modal-alert");
    dlg.id = "dialog-alert";
    dlg.setAttribute("aria-labelledby", "judul-alert");
    document.body.append(dlg);
    pasangTutupLuar(dlg);
  }
  const jenis = tipe || "info";
  const simbol = { galat: "!", sukses: "✓", info: "i" }[jenis];
  const judulEl = buat("h2", null, judul);
  judulEl.id = "judul-alert";
  const tutup = buat("button", "tombol tombol-utama", "Mengerti");
  tutup.type = "button";
  tutup.addEventListener("click", () => dlg.close());
  dlg.replaceChildren(buat("div", "ikon-alert ikon-" + jenis, simbol), judulEl, buat("p", null, pesan), tutup);
  if (!dlg.open) dlg.showModal();
}

// Klik di area gelap (backdrop) menutup dialog
function pasangTutupLuar(dlg) {
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });
}

function pasangModal() {
  document.querySelectorAll("[data-buka]").forEach((tombol) => {
    tombol.addEventListener("click", () => document.getElementById(tombol.dataset.buka).showModal());
  });
  document.querySelectorAll("dialog.modal").forEach((dlg) => {
    pasangTutupLuar(dlg);
    dlg.addEventListener("close", () => {
      const form = dlg.querySelector("form");
      if (form) {
        form.reset();
        form.querySelectorAll("input").forEach((i) => setGalat(i.id, ""));
      }
    });
  });
  document.querySelectorAll("[data-tutup]").forEach((tombol) => {
    tombol.addEventListener("click", () => tombol.closest("dialog").close());
  });
}

/* ---------- Navbar (dipakai dashboard, tracking, stok) ---------- */

function renderNavbar() {
  const pengguna = penggunaAktif();
  const nav = document.getElementById("navbar");
  const dalam = buat("div", "navbar-dalam");

  const merek = buat("a", "navbar-merek", "SITTA");
  merek.href = "dashboard.html";

  const menu = buat("ul", "navbar-menu");
  const butir = (teks, href, kunci) => {
    const li = buat("li");
    const a = buat("a", null, teks);
    a.href = href;
    a.dataset.kunci = kunci;
    li.append(a);
    return li;
  };

  // Dropdown "Laporan"
  const liLaporan = buat("li", "dropdown");
  const tombolLaporan = buat("button", "menu-btn", "Laporan ▾");
  tombolLaporan.type = "button";
  tombolLaporan.dataset.kunci = "laporan";
  tombolLaporan.setAttribute("aria-haspopup", "true");
  tombolLaporan.setAttribute("aria-expanded", "false");
  const isiLaporan = buat("ul", "dropdown-isi");
  isiLaporan.append(
    butir("Monitoring Progress DO Bahan Ajar", "dashboard.html#monitoring", "monitoring"),
    butir("Rekap Bahan Ajar", "dashboard.html#rekap", "rekap")
  );
  tombolLaporan.addEventListener("click", (e) => {
    e.stopPropagation();
    const buka = liLaporan.classList.toggle("terbuka");
    tombolLaporan.setAttribute("aria-expanded", String(buka));
  });
  document.addEventListener("click", () => {
    liLaporan.classList.remove("terbuka");
    tombolLaporan.setAttribute("aria-expanded", "false");
  });
  liLaporan.append(tombolLaporan, isiLaporan);

  menu.append(
    butir("Informasi Bahan Ajar", "stok.html", "stok"),
    butir("Tracking Pengiriman", "tracking.html", "tracking"),
    liLaporan,
    butir("Histori Transaksi Bahan Ajar", "dashboard.html#histori", "histori")
  );

  const kanan = buat("div", "navbar-pengguna");
  const keluar = buat("button", "tombol tombol-tepi tombol-kecil", "Keluar");
  keluar.type = "button";
  keluar.addEventListener("click", () => {
    sessionStorage.removeItem(KUNCI_SESI);
    location.href = "index.html";
  });
  kanan.append(buat("span", null, pengguna ? pengguna.nama : ""), keluar);

  dalam.append(merek, menu, kanan);
  const wadah = buat("nav");
  wadah.setAttribute("aria-label", "Menu utama");
  wadah.append(dalam);
  nav.replaceChildren(wadah);
}

// Menandai menu yang sedang aktif
function tandaiNavbar(kunci) {
  document.querySelectorAll("#navbar [data-kunci]").forEach((el) => {
    const induk = el.dataset.kunci === "laporan" && (kunci === "monitoring" || kunci === "rekap");
    el.classList.toggle("aktif", el.dataset.kunci === kunci || induk);
  });
}

/* ---------- Komponen tampilan bersama ---------- */

function buatBadge(idx) {
  return buat("span", "badge s" + idx, TAHAP_KIRIM[idx]);
}

function buatProgress(idx) {
  const persen = Math.round((idx / (TAHAP_KIRIM.length - 1)) * 100);
  const bungkus = buat("span");
  const bar = buat("span", "bar" + (idx === TAHAP_KIRIM.length - 1 ? " penuh" : ""));
  const isi = buat("span");
  isi.style.width = persen + "%";
  bar.append(isi);
  bungkus.append(bar, document.createTextNode(persen + "%"));
  return bungkus;
}

function buatSampul(b) {
  const bungkus = buat("span", "sampul");
  bungkus.append(buat("span", "sampul-inisial", b.kodeBarang.slice(0, 4)));
  if (b.cover) {
    const img = buat("img");
    img.src = b.cover;
    img.alt = "Sampul " + b.namaBarang;
    img.loading = "lazy";
    img.addEventListener("error", () => img.remove()); // file gambar tidak ada: tampilkan inisial
    bungkus.append(img);
  }
  return bungkus;
}

function buatBaris(kolom, data) {
  const tr = buat("tr");
  kolom.forEach((k) => {
    const td = buat("td", k.kelas);
    const isi = k.isi(data);
    if (isi instanceof Node) td.append(isi); else td.textContent = isi;
    tr.append(td);
  });
  return tr;
}

function buatTabel(keterangan, kolom, baris) {
  const bungkus = buat("div", "tabel-gulir");
  const tabel = buat("table");
  const thead = buat("thead");
  const trHead = buat("tr");
  kolom.forEach((k) => {
    const th = buat("th", k.kelas, k.judul);
    th.scope = "col";
    trHead.append(th);
  });
  thead.append(trHead);
  const tbody = buat("tbody");
  baris.forEach((b) => tbody.append(buatBaris(kolom, b)));
  tabel.append(buat("caption", "sr-saja", keterangan), thead, tbody);
  bungkus.append(tabel);
  return { bungkus, tbody };
}

/* =====================================================
   HALAMAN LOGIN
   ===================================================== */

function initLogin() {
  if (penggunaAktif()) { location.replace("dashboard.html"); return; }
  pasangModal();

  const form = document.getElementById("form-login");
  const inputPassword = document.getElementById("password");

  document.getElementById("lihat-password").addEventListener("change", (e) => {
    inputPassword.type = e.target.checked ? "text" : "password";
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = inputPassword.value;

    let ok = true;
    if (!email) { setGalat("email", "Email wajib diisi."); ok = false; }
    else if (!emailValid(email)) { setGalat("email", "Format email belum benar, contoh: nama@ut.ac.id."); ok = false; }
    else setGalat("email", "");

    if (!password) { setGalat("password", "Password wajib diisi."); ok = false; }
    else setGalat("password", "");
    if (!ok) return;

    const pengguna = semuaPengguna().find((p) => p.email.toLowerCase() === email && p.password === password);
    if (!pengguna) {
      tampilAlert("Login gagal", "Email/password yang Anda masukkan salah.", "galat");
      return;
    }
    sessionStorage.setItem(KUNCI_SESI, JSON.stringify({ nama: pengguna.nama, email: pengguna.email, role: pengguna.role, lokasi: pengguna.lokasi }));
    location.href = "dashboard.html";
  });

  // Modal: Lupa password
  document.getElementById("form-lupa").addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("lupa-email").value.trim().toLowerCase();
    if (!email) return setGalat("lupa-email", "Email wajib diisi.");
    if (!emailValid(email)) return setGalat("lupa-email", "Format email belum benar.");
    if (!semuaPengguna().some((p) => p.email.toLowerCase() === email)) {
      return setGalat("lupa-email", "Email ini belum terdaftar.");
    }
    document.getElementById("modal-lupa").close();
    tampilAlert("Tautan terkirim", "Tautan reset password telah dikirim ke " + email + " (simulasi).", "sukses");
  });

  // Modal: Daftar
  document.getElementById("form-daftar").addEventListener("submit", (e) => {
    e.preventDefault();
    const nama = document.getElementById("daftar-nama").value.trim();
    const email = document.getElementById("daftar-email").value.trim().toLowerCase();
    const pass = document.getElementById("daftar-password").value;
    const ulang = document.getElementById("daftar-ulang").value;

    const galat = {
      "daftar-nama": nama.length < 3 ? "Nama minimal 3 karakter." : "",
      "daftar-email": !emailValid(email) ? "Format email belum benar." :
        semuaPengguna().some((p) => p.email.toLowerCase() === email) ? "Email ini sudah terdaftar." : "",
      "daftar-password": pass.length < 6 ? "Password minimal 6 karakter." : "",
      "daftar-ulang": ulang !== pass ? "Password tidak sama." : ""
    };
    Object.entries(galat).forEach(([id, pesan]) => setGalat(id, pesan));
    if (Object.values(galat).some(Boolean)) return;

    let tambahan = [];
    try { tambahan = JSON.parse(localStorage.getItem(KUNCI_DAFTAR)) || []; } catch (err) { /* abaikan */ }
    tambahan.push({ nama, email, password: pass, role: "Pengguna", lokasi: "-" });
    localStorage.setItem(KUNCI_DAFTAR, JSON.stringify(tambahan));

    document.getElementById("modal-daftar").close();
    tampilAlert("Pendaftaran berhasil", "Akun " + email + " sudah dibuat. Silakan login.", "sukses");
  });
}

/* =====================================================
   HALAMAN DASHBOARD
   ===================================================== */

function sapaanWaktu(jam) {
  if (jam >= 4 && jam < 11) return "pagi";
  if (jam >= 11 && jam < 15) return "siang";
  if (jam >= 15 && jam < 18) return "sore";
  return "malam";
}

function tampilkanGreeting() {
  const pengguna = penggunaAktif();
  const perbarui = () => {
    const sekarang = new Date();
    document.getElementById("greeting").textContent =
      "Selamat " + sapaanWaktu(sekarang.getHours()) + ", " + pengguna.nama;
    document.getElementById("jam").textContent =
      sekarang.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) +
      ", " + sekarang.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }) + " (waktu perangkat)";
  };
  perbarui();
  setInterval(perbarui, 30000);
}

function isiRingkasan() {
  const totalStok = dataBahanAjar.reduce((n, b) => n + b.stok, 0);
  const menipis = dataBahanAjar.filter((b) => b.stok < BATAS_STOK_MENIPIS).length;
  const aktif = daftarTracking.filter((d) => d.statusIdx < TAHAP_KIRIM.length - 1).length;
  const kartu = [
    [dataBahanAjar.length, "Judul bahan ajar", ""],
    [totalStok.toLocaleString("id-ID"), "Total eksemplar di gudang", ""],
    [aktif, "DO masih dalam proses", ""],
    [menipis, "Judul dengan stok di bawah " + BATAS_STOK_MENIPIS, menipis > 0 ? " peringatan" : ""]
  ];
  const wadah = document.getElementById("kartu-angka");
  kartu.forEach(([angka, label, ekstra]) => {
    const k = buat("div", "angka" + ekstra);
    k.append(buat("strong", null, angka), buat("span", null, label));
    wadah.append(k);
  });
}

function isiMonitoring() {
  const kolom = [
    { judul: "Nomor DO", isi: (d) => d.nomorDO },
    { judul: "Mahasiswa", isi: (d) => d.nama },
    { judul: "Ekspedisi", isi: (d) => d.ekspedisi },
    { judul: "Status", isi: (d) => buatBadge(d.statusIdx) },
    { judul: "Progress", isi: (d) => buatProgress(d.statusIdx) }
  ];
  document.getElementById("isi-monitoring")
    .append(buatTabel("Progress pengiriman per nomor DO", kolom, daftarTracking).bungkus);
}

function isiRekap() {
  const baris = [...dataBahanAjar].sort((x, y) => y.stok - x.stok);
  baris.push({
    kodeBarang: "", namaBarang: "Total " + baris.length + " judul", kodeLokasi: "",
    stok: baris.reduce((n, x) => n + x.stok, 0)
  });
  const kolom = [
    { judul: "Kode barang", isi: (x) => x.kodeBarang },
    { judul: "Nama barang", isi: (x) => x.namaBarang },
    { judul: "Jenis", isi: (x) => x.jenisBarang || "" },
    { judul: "Kode lokasi", isi: (x) => x.kodeLokasi },
    { judul: "Total stok", kelas: "angka-kolom", isi: (x) => x.stok.toLocaleString("id-ID") }
  ];
  const { bungkus, tbody } = buatTabel("Rekap stok per bahan ajar", kolom, baris);
  tbody.lastElementChild.classList.add("total");
  document.getElementById("isi-rekap").append(bungkus);
}

function isiHistori() {
  const pilihan = document.getElementById("filter-status");
  pilihan.append(new Option("Semua status", ""));
  TAHAP_KIRIM.forEach((t, i) => pilihan.append(new Option(t, String(i))));

  const kolom = [
    { judul: "Tanggal kirim", isi: (d) => tanggalPanjang(d.tanggalKirim) },
    { judul: "Nomor DO", isi: (d) => d.nomorDO },
    { judul: "Mahasiswa", isi: (d) => d.nama },
    { judul: "Paket", isi: (d) => namaPaket(d.paket) },
    { judul: "Total", kelas: "angka-kolom", isi: (d) => d.total },
    { judul: "Status", isi: (d) => buatBadge(d.statusIdx) }
  ];
  const urut = [...daftarTracking].sort((a, b) => b.tanggalKirim.localeCompare(a.tanggalKirim));
  const { bungkus, tbody } = buatTabel("Histori transaksi bahan ajar", kolom, urut);
  document.getElementById("isi-histori").append(bungkus);

  pilihan.addEventListener("change", () => {
    const dipilih = pilihan.value;
    const tersaring = dipilih === "" ? urut : urut.filter((d) => String(d.statusIdx) === dipilih);
    tbody.replaceChildren(...tersaring.map((d) => buatBaris(kolom, d)));
    if (!tersaring.length) {
      const tr = buat("tr");
      const td = buat("td", null, "Belum ada transaksi dengan status ini.");
      td.colSpan = kolom.length;
      tr.append(td);
      tbody.append(tr);
    }
  });
}

function initDashboard() {
  tampilkanGreeting();
  isiRingkasan();
  isiMonitoring();
  isiRekap();
  isiHistori();

  const tampilPanel = () => {
    let kunci = location.hash.slice(1) || "ringkasan";
    if (!document.getElementById("panel-" + kunci)) kunci = "ringkasan";
    document.querySelectorAll(".panel").forEach((p) => { p.hidden = p.id !== "panel-" + kunci; });
    // Hanya satu panel yang tampil; tanpa hash, panel ringkasan yang tampil
    tandaiNavbar(kunci === "ringkasan" ? "" : kunci);
  };
  window.addEventListener("hashchange", tampilPanel);
  tampilPanel();
}

/* =====================================================
   HALAMAN TRACKING
   ===================================================== */

function tampilkanHasil(d) {
  const kotak = document.getElementById("hasil");
  kotak.hidden = false;

  const judul = buat("div");
  judul.append(buat("h2", null, d.nama), buat("p", null, "Nomor DO " + d.nomorDO));
  const kepala = buat("header", "hasil-kepala");
  kepala.append(judul, buatBadge(d.statusIdx));

  const tahap = buat("ol", "tahap");
  TAHAP_KIRIM.forEach((t, i) => {
    const li = buat("li", i < d.statusIdx || d.statusIdx === TAHAP_KIRIM.length - 1 ? "selesai" : i === d.statusIdx ? "aktif" : "", t);
    if (i === d.statusIdx && d.statusIdx !== TAHAP_KIRIM.length - 1) li.setAttribute("aria-current", "step");
    tahap.append(li);
  });

  const detail = buat("dl", "detail");
  [
    ["Ekspedisi", d.ekspedisi],
    ["Tanggal kirim", tanggalPanjang(d.tanggalKirim)],
    ["Jenis paket", namaPaket(d.paket)],
    ["Total pembayaran", d.total]
  ].forEach(([label, nilai]) => {
    const bagian = buat("div");
    bagian.append(buat("dt", null, label), buat("dd", null, nilai));
    detail.append(bagian);
  });

  const jalan = buat("ol", "perjalanan");
  [...d.perjalanan].reverse().forEach((p) => { // terbaru di atas
    const li = buat("li");
    const waktu = buat("time", null, p.waktu);
    waktu.dateTime = p.waktu.replace(" ", "T");
    li.append(waktu, document.createTextNode(p.keterangan));
    jalan.append(li);
  });

  kotak.replaceChildren(kepala, tahap, detail, buat("h2", null, "Perjalanan paket"), jalan);
}

function initTracking() {
  const input = document.getElementById("nomor-do");
  const kotak = document.getElementById("hasil");

  // Chip nomor DO contoh
  const wadahContoh = document.getElementById("contoh-do");
  daftarTracking.forEach((d) => {
    const b = buat("button", "tautan", d.nomorDO);
    b.type = "button";
    b.addEventListener("click", () => { input.value = d.nomorDO; input.focus(); });
    wadahContoh.append(b);
  });

  document.getElementById("form-tracking").addEventListener("submit", (e) => {
    e.preventDefault();
    const nomor = input.value.trim();
    if (!nomor) {
      setGalat("nomor-do", "Nomor DO wajib diisi.");
      kotak.hidden = true;
      return;
    }
    if (!/^\d+$/.test(nomor)) {
      setGalat("nomor-do", "Nomor DO hanya berisi angka.");
      kotak.hidden = true;
      return;
    }
    setGalat("nomor-do", "");
    const data = daftarTracking.find((d) => d.nomorDO === nomor);
    if (!data) {
      kotak.hidden = true;
      tampilAlert("Nomor DO tidak ditemukan", "Tidak ada pengiriman dengan nomor " + nomor + ". Periksa lagi nomor Delivery Order Anda.", "galat");
      return;
    }
    tampilkanHasil(data);
  });
}

/* =====================================================
   HALAMAN STOK
   ===================================================== */

function initStok() {
  const kolom = [
    { judul: "Sampul", isi: (b) => buatSampul(b) },
    { judul: "Kode lokasi", isi: (b) => b.kodeLokasi },
    { judul: "Kode barang", isi: (b) => b.kodeBarang },
    { judul: "Nama barang", isi: (b) => b.namaBarang },
    { judul: "Jenis", isi: (b) => b.jenisBarang },
    { judul: "Edisi", kelas: "angka-kolom", isi: (b) => b.edisi },
    {
      judul: "Stok", kelas: "angka-kolom",
      isi: (b) => {
        const s = buat("span", null, b.stok.toLocaleString("id-ID"));
        if (b.stok < BATAS_STOK_MENIPIS) s.append(buat("span", "badge menipis", "Menipis"));
        return s;
      }
    },
    {
      judul: "Aksi",
      isi: (b) => {
        const tombol = buat("button", "tombol tombol-kecil tombol-bahaya", "Hapus");
        tombol.type = "button";
        tombol.setAttribute("aria-label", "Hapus " + b.namaBarang);
        tombol.addEventListener("click", () => hapusBaris(b, tombol.closest("tr")));
        return tombol;
      }
    }
  ];

  const { bungkus, tbody } = buatTabel("Daftar stok bahan ajar", kolom, dataBahanAjar);
  document.getElementById("tabel-stok").append(bungkus);

  const ringkas = () => {
    const total = dataBahanAjar.reduce((n, b) => n + b.stok, 0);
    document.getElementById("ringkas-stok").textContent =
      dataBahanAjar.length + " judul, total " + total.toLocaleString("id-ID") + " eksemplar";
  };
  ringkas();

  function hapusBaris(barang, tr) {
    if (!confirm("Hapus " + barang.namaBarang + " (" + barang.kodeBarang + ") dari daftar stok?")) return;
    dataBahanAjar.splice(dataBahanAjar.indexOf(barang), 1);
    tr.remove();
    ringkas();
    saring();
  }

  // Pencarian / filter tabel
  const cari = document.getElementById("cari-stok");
  function saring() {
    const kata = cari.value.trim().toLowerCase();
    let terlihat = 0;
    Array.from(tbody.rows).forEach((tr) => {
      const cocok = tr.textContent.toLowerCase().includes(kata);
      tr.hidden = !cocok;
      if (cocok) terlihat += 1;
    });
    document.getElementById("stok-kosong").hidden = terlihat > 0;
  }
  cari.addEventListener("input", saring);

  // Form tambah stok
  const form = document.getElementById("form-stok");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const kodeLokasi = document.getElementById("kodeLokasi").value.trim().toUpperCase();
    const kodeBarang = document.getElementById("kodeBarang").value.trim().toUpperCase();
    const nama = document.getElementById("namaBarang").value.trim();
    const jenis = document.getElementById("jenisBarang").value;
    const edisi = document.getElementById("edisi").value;
    const stok = document.getElementById("stok").value;

    const galat = {
      kodeLokasi: !kodeLokasi ? "Kode lokasi wajib diisi." : "",
      kodeBarang: !kodeBarang ? "Kode barang wajib diisi."
        : dataBahanAjar.some((b) => b.kodeBarang === kodeBarang) ? "Kode barang ini sudah ada di daftar." : "",
      namaBarang: nama.length < 3 ? "Nama barang minimal 3 karakter." : "",
      jenisBarang: !jenis ? "Pilih jenis barang." : "",
      edisi: !/^[1-9]\d*$/.test(edisi) ? "Edisi berupa bilangan bulat, minimal 1." : "",
      stok: !/^\d+$/.test(stok) ? "Stok berupa bilangan bulat, minimal 0." : ""
    };
    Object.entries(galat).forEach(([id, pesan]) => setGalat(id, pesan));
    if (Object.values(galat).some(Boolean)) {
      tampilAlert("Data belum lengkap", "Periksa kolom yang ditandai merah, lalu coba lagi.", "galat");
      return;
    }

    const barang = { kodeLokasi, kodeBarang, namaBarang: nama, jenisBarang: jenis, edisi: String(edisi), stok: Number(stok), cover: "" };
    dataBahanAjar.push(barang);
    const tr = buatBaris(kolom, barang);
    tr.classList.add("baru");
    tbody.append(tr);
    ringkas();
    saring();
    form.reset();
    tampilAlert("Stok ditambahkan", nama + " (" + kodeBarang + ") masuk ke daftar stok.", "sukses");
  });
}

/* =====================================================
   INISIALISASI
   ===================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const halaman = document.body.dataset.halaman;

  if (halaman === "login") { initLogin(); return; }

  // Halaman lain wajib login
  if (!penggunaAktif()) { location.replace("index.html"); return; }
  renderNavbar();
  tandaiNavbar(halaman);

  if (halaman === "dashboard") initDashboard();
  if (halaman === "tracking") initTracking();
  if (halaman === "stok") initStok();
});
